import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-tour',
  templateUrl: './completed-tour.component.html',
  styleUrls: ['./completed-tour.component.scss']
})
export class CompletedTourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
