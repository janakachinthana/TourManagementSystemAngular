export class Vehicle {

    VehicleID:number;
    VehicleNo :string
    Brand :string
    Model :string
    RegistrationNo :string
    ManuYr :number;
    NoOfSeats :number;
    OwnersName :string
    OwneresID :string
    OwnersContact :string
    VehicleInsuaranceNo :string
    RatePerKM :number;

}

