import { Guide } from './guide.model';

describe('Guide', () => {
  it('should create an instance', () => {
    expect(new Guide()).toBeTruthy();
  });
});
