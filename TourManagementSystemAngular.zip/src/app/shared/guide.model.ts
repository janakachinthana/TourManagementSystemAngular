export class Guide {

        GuideID : number;
        FirstName : string;
        LastName : string;
        Address : string;
        BirthDay : string;
        NicNo : string;
        Email  : string;
        ContactNo : number;
        Gender : string;
        Languages : string;
        Price  : number;
        Image : string;
       
        
    
}
