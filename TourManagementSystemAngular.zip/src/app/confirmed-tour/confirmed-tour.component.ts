import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmed-tour',
  templateUrl: './confirmed-tour.component.html',
  styleUrls: ['./confirmed-tour.component.scss']
})
export class ConfirmedTourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
